import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Our Story",
  description: "Meet Kassandra Huston, founder of The Nourished Garden & Farm, and learn what inspired her family-centered approach to holistic wellness.",
};

export default function BioPage() {
  return (
    <main className="bio-page">
      <section className="bio-hero">
        <div className="bio-hero-copy garden-surface">
          <p className="eyebrow">Meet the founder</p>
          <h1>Kassandra Huston</h1>
          <p className="bio-lede">A mother, health coach, and lifelong helper creating a more grounded path to family wellness.</p>
        </div>
      </section>

      <section className="bio-story garden-surface">
        <div>
          <p className="eyebrow">Why I began</p>
          <h2>From the medical field to a whole-person approach</h2>
        </div>
        <div className="bio-copy">
          <p>I spent 11 years working in the medical field. I valued helping people, but over time I felt called to support families in a more personal and practical way—before everyday stress and unhealthy patterns became even harder to manage.</p>
          <p>My own family shaped this journey. I started looking more closely at our food, routines, and home environment. We cooked more from scratch and gradually moved away from ultra-processed foods. Learning how to make those changes in real family life taught me that wellness does not have to begin with perfection. It can begin with one steady step.</p>
          <p>Those experiences deepened my desire to learn and reminded me how important it is for people to feel heard, supported, and empowered to participate in their own wellness while continuing to work with qualified healthcare professionals.</p>
        </div>
      </section>

      <section className="bio-values">
        <article className="member-garden-card">
          <span className="bio-icon">🌿</span>
          <h3>Practical, not perfect</h3>
          <p>I help families choose realistic habits they can actually carry into busy days.</p>
        </article>
        <article className="member-garden-card">
          <span className="bio-icon">🥕</span>
          <h3>Rooted in real life</h3>
          <p>Food, gardening, home rhythms, rest, and family connection all belong in the conversation.</p>
        </article>
        <article className="member-garden-card">
          <span className="bio-icon">🤝</span>
          <h3>Support without judgment</h3>
          <p>Every family starts somewhere. My role is to listen, encourage, and help you find a manageable next step.</p>
        </article>
      </section>

      <section className="bio-credentials garden-surface">
        <div>
          <p className="eyebrow">Experience &amp; education</p>
          <h2>A foundation of service and continued learning</h2>
        </div>
        <ul>
          <li><strong>11 years</strong> of experience in the medical billing field</li>
          <li><strong>Primal Health &amp; Nutrition Expert</strong> certification</li>
          <li><strong>Human Intestinal Microbiome in Health and Disease Specialist</strong> certification</li>
          <li>A personal focus on whole-food nutrition, calmer routines, family wellness, and practical gardening skills</li>
        </ul>
      </section>

      <section className="bio-closing garden-surface">
        <p className="eyebrow">The Nourished Garden &amp; Farm</p>
        <h2>Nourishing the body from the soil to the soul.</h2>
        <p>I created this business for individuals and families who feel overwhelmed and want a gentler, more sustainable way forward. You do not have to change everything at once. We can begin with the next nourishing step.</p>
        <div className="button-row">
          <a className="button button-primary" href="https://calendly.com/thenourishedgardens/calm-call" target="_blank" rel="noreferrer">Book a free call</a>
          <Link className="button button-secondary" href="/programs">Explore programs</Link>
        </div>
        <p className="fine-print bio-disclaimer">Health coaching is educational and supportive. It does not replace medical care, diagnosis, or treatment.</p>
      </section>
    </main>
  );
}
